

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%config inlinebackend.figure_format='svg'
```


```python
x = np.linspace(0,4 * np.pi, 1000)
volts = np.sin(x)+ 0.25 * np.random.rand(len(x))
current = np.cos(x) + 0.25 * np.random.rand(len(x))

plt.plot(x, volts, label='volts')
plt.plot(x, current, label='current')
plt.show()
```


![png](output_1_0.png)



```python

```


```python

```
